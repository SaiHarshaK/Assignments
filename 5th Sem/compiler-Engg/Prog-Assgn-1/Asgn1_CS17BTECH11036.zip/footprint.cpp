#define DEBUG_TYPE "footprint"
#include "llvm/Pass.h"
#include "llvm/IR/Instruction.h"
#include "llvm/IR/Constants.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Metadata.h"
#include "llvm/IR/DebugLoc.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/InstIterator.h"
#include "llvm/ADT/iterator_range.h"
#include "llvm/IR/DebugInfoMetadata.h"
#include "llvm/IR/IntrinsicInst.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/Function.h"
#include "llvm/Analysis/AliasAnalysis.h"
#include "llvm/IR/SymbolTableListTraits.h"
#include "llvm/IR/Use.h"
#include "llvm/IR/Value.h"
#include <iterator>
#include <string>
#include <sstream>
#include <utility>

using namespace llvm;
using namespace std;

static cl::opt<std::string> varName("var-name", cl::desc("Variable name: "), cl::value_desc("name"));

namespace {
  struct varData {
    Value* valptr;
    vector<int> lines;
    int reads = 0;
    int writes = 0;
  };

  struct footprint : public FunctionPass {
    static char ID;
    bool passInfo = false;
    footprint() : FunctionPass(ID) {}

    void getAnalysisUsage(AnalysisUsage &AU) const {
      AU.setPreservesCFG();
      AU.addRequired<AAResultsWrapperPass>();
    }

    bool runOnFunction(Function &F) {
      if (!passInfo) {
        errs() << "Clang version: 9.0.0\n";
        errs() << "LLVM Source Repository: https://github.com/llvm/llvm-project.git\n";
        errs() << "LLVM Commit Hash: 0399d5a9682b3cef71c653373e38890c63c4c365\n";
        errs() << "Clang Source Repository: https://github.com/llvm-mirror/clang\n";
        errs() << "LLVM Commit Hash: 0399d5a9682b3cef71c653373e38890c63c4c365\n";
        errs() << "Target: x86_64-unknown-linux-gnu\n";
        passInfo = true;
      }
      string reqd = varName;
      vector<varData> insts;
      // find all the allocas corresponding to varName and store their address.
      for(auto I = inst_begin(F); I != inst_end(F); I++) {
        if (isa<CallInst>(*I)) {
          StringRef name = cast<CallInst>(*I).getCalledValue()->getName();
          if (name == "llvm.dbg.declare") {
            auto a = I->getOperand(1);
            auto divar = cast<DIVariable>(cast<MetadataAsValue>(a)->getMetadata());
            if (divar->getName() == reqd) {
              struct varData inst;
              auto dbgInst = cast<DbgDeclareInst>(&(*I));
              inst.valptr = dbgInst->getAddress();
              if(!I->getDebugLoc())
                  inst.lines.push_back(-1); // should not occur
              else inst.lines.push_back(I->getDebugLoc()->getLine());
              // check if that already exists in insts
              bool flag = false;
              for (auto i = insts.begin(); i != insts.end(); i++) {
                if (inst.valptr == i->valptr)
                  break;
              }
              if (flag == false)
                insts.push_back(inst);
            }
          }
        }
      }
      // object for alias analysis
      AAResults &AA = getAnalysis<AAResultsWrapperPass>().getAAResults();

      // this loop is for going through load and store operations and getting their count
      for(auto I = inst_begin(F); I != inst_end(F); I++) {
        if (I->getNumOperands() == 0)
          continue;
        // load type
        if(isa<LoadInst>(*I)) {
         // errs()<<"loadType: " << I->getNumOperands() <<"\n";
         // if (I->getNumOperands() == 1) {
         //  I->dump();
         // }
          // 1st operand check for required inst
          for (auto i = insts.begin(); i != insts.end(); i++) {
            if(int(AA.alias(I->getOperand(0), i->valptr)) == 0) { // 0 is considered not equal while other values are considered as a possibilty of a match, we assume they are same.
              continue;
            }
            // handle errors
            if(!I->getDebugLoc())
              continue;
            // we can store line number now
            int lineno = I->getDebugLoc()->getLine();
            if(find(i->lines.begin(), i->lines.end(), lineno) == i->lines.end()) { // not added yet so add them
              i->lines.push_back(lineno);
            }
            i->reads++;
            break;
          }
        }
        // store type
        if(isa<StoreInst>(*I)) {
          // errs()<<"storeType: " << I->getNumOperands() <<"\n";
          // 1st operand check for required inst (we are reading if this is the case)
          for (auto i = insts.begin(); i != insts.end(); i++) {
            if(int(AA.alias(I->getOperand(0), i->valptr)) == 0) {
              continue;
            }
            // handle errors
            if(!I->getDebugLoc())
              continue;
            // we can store line number now
            int lineno = I->getDebugLoc()->getLine();
            if(find(i->lines.begin(), i->lines.end(), lineno) == i->lines.end()) { // not added yet
              i->lines.push_back(lineno);
            }
            i->reads++;
            break;
          }
          // second operand check for required inst (we are writing if this is the case)
          for (auto i = insts.begin(); i != insts.end(); i++) {
            if(int(AA.alias(I->getOperand(1), i->valptr)) == 0) {
              continue;
            }
            // handle errors
            if(!I->getDebugLoc())
              continue;
            // we can store line number now
            int lineno = I->getDebugLoc()->getLine();
            if(find(i->lines.begin(), i->lines.end(), lineno) == i->lines.end()) { // not added yet
              i->lines.push_back(lineno);
            }
            i->writes++;
            break;
          }
        }
      }
      int size = insts.size();
      for(int i = 0; i < size ; i++) {
        errs() << "Variable Name: " << varName << "\n";
        errs() << "Variable Scope: " << insts[i].lines[0] << ":" << "\n";
        errs() << "Footprint: ";
        int size1 = insts[i].lines.size() - 1;
        for(int j = 0; j < size1; j++) {
          errs() << insts[i].lines[j];
            errs() << ", ";
        } errs() << insts[i].lines[insts[i].lines.size() - 1] << "\n";
        errs() << "Number of Reads: " << insts[i].reads << "\n";
        errs() << "Number of Writes: " << insts[i].writes << "\n";
      }
      return false;
    }
  };
}

char footprint::ID = 0;
static RegisterPass<footprint> X("footprint", "footprint of all varibles");
