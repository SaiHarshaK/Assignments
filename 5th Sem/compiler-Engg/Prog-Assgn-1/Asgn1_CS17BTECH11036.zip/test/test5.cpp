#include <iostream>

int main() {
  int a = 0;
  int b = 1;
  int c = 0;
  int d = 0;
  int e = 0;
  return a * b - c / e + d;
}
