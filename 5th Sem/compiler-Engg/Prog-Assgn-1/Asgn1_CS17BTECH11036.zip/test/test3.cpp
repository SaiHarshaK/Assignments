// different scope and nested loop
#include <stdio.h>

int main() {
  int i = 0;
  for (int i = 0; i < 1; i++) {
    for(int j  = 0; j < 1; j++) {
      i = 1;
    }
  }

  return 0;
}
