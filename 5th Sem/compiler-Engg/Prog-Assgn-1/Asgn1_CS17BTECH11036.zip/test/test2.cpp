#include <stdio.h>

int main() {
  int x = 1;
  int *y = &x;
  *y = 2;
  x = 3;

  return 0;
}
