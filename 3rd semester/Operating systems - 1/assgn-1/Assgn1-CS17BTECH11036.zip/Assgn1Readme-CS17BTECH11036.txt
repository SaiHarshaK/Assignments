Author        - Sai Harsha Kottapalli
Use           - given a command (with its parameters if necessary), executes the command and outputs the time taken to execute the command.
Instructions  - give the command and its parameters(if any) along when runny the binary file.
                Example -
                  Input:
                    ./a.out ls -la
                  Output:
                    total 52
                    drwxr-xr-x 2 harsha users  4096 Nov 15 20:13 .
                    drwxr-xr-x 3 harsha users  4096 Nov 15 15:04 ..
                    -rwxr-xr-x 1 harsha users 18192 Nov 15 20:13 a.out
                    -rw-r--r-- 1 harsha users     0 Nov 15 20:07 Assgn1Readme-CS17BTECH11036.txt
                    -rwxr-xr-x 1 harsha users 18344 Nov 15 19:36 Assgn1Src-CS17BTECH11036
                    -rw-r--r-- 1 harsha users  1377 Nov 15 20:04 Assgn1Src-CS17BTECH11036.cpp
                    Elapsed time: 0.0058620000 seconds
