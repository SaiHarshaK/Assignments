"""
CS6890 - Assignment 5 - Implementation of Collusion Clustering

From Section 4.3 in --
Palshikar, Girish & Apte, Manoj. (2008). Collusion set detection using graph
clustering. Data Min. Knowl. Discov.. 16. 135-164. 10.1007/s10618-007-0076-8. 

Authors:
    Tanmay R     -- CS17BTECH11042
    Sai Harsha K -- CS17BTECH11036
"""
import sys
import numpy as np
import pandas as pd
#import networkx as nx
import itertools as it
#import matplotlib.pyplot as plt 

def union(a, b):
    """Given two lists a and b, returns a list which is the union of both
    the lists

    Attributes:
        a -- first list
        b -- second list

    Output:
        l -- union of both lists
    """
    return sorted(list(set(a) | set(b)))

def generate_singletons(n):
    """Returns a list with singleton lists of linearly increasing numbers from 
    0 to n-1

    Attributes:
        n -- size of array needed

    Outputs:
        arr -- generated list of singleton lists

    Example:
        input: generate_singletons(3)

        output: [[0], [1], [2]]
    """
    arr = []
    for i in range(0, n):
        arr.append([i])
    return arr

def generate_stockflow_graph(dataset):
    """Generates a stock-flow graph on the basis of given dataset. Returns an
    array with labels of all vertices in order (labels are traderIDs), and an
    adjacency matrix for the stockflow graph.

    Attributes:
        dataset -- csv dataset with three columns seller,buyer,amount
        Note: Function assumes that first row of dataset is the header row with
        "seller,buyer,amount"

    Outputs:
        ids -- labels of vertices in sequential order (labels are traderIDs)
        g   -- adjacency matrix of stockflow graph
    """
    # Assumes CSV has header of seller,buyer,amount 
    data = pd.read_csv(dataset)
    # Array that has unique ids
    ids = []
    for row in data.values:
        if row[0] not in ids:
            ids.append(row[0])
        if row[1] not in ids:
            ids.append(row[1])
    # No. of unique nodes
    nodes = len(ids)
    # Create a zeros array for adjaceny matrix of graph
    g = np.zeros((nodes, nodes))
    # populate adjacency matrix
    for row in data.values:
        i = ids.index(row[0])
        j = ids.index(row[1])
        g[i][j] += row[2]
    return (ids, g)

def knn(row, k):
    """Returns the indices of the k-nearest neighbors from vertex v, given the
    distance of all other vertices from v

    Attributes:
        row -- distance of all vertices from vertex v 
               (v's row in the adjacency matrix of the graph)
        k   -- number of nearest neighbors

    Outputs:
       arr -- an array of length k, which contains the indices of k-nearest
              neighbors, sorted by closest to farthest.
    """
    return np.argsort(-row)[:K]

def internal_trading(g, clst):
    """Internal Trading is the total sum of all recorded trades between (i, j) 
    where i and j belong to the same cluster.

    Attributes:
        g    -- adjacency matrix of stockflow graph
        clst -- indices of all vertices in cluster

    Outputs:
        r -- total value of internal trading 
    """
    r = 0
    for i in clst:
        for j in clst:
            r += g[i][j]
    return r

def external_trading(g, clst):
    """External Trading is the total sum of all recorded trades between (i, j) 
    where only one of i or j belong to the cluster.

    Attributes:
        g    -- adjacency matrix of stockflow graph
        clst -- indices of all vertices in cluster

    Outputs:
        r -- total value of external trading 
    """
    nodes = len(g)
    # all_nodes is a list of nodes = [0, 1, 2, 3, ..., n]
    all_nodes = np.arange(nodes)
    # not_clst = all_nodes - clst
    not_clst = [i for i in all_nodes if i not in clst]
    r = 0
    for i in clst:
        for j in not_clst:
            r += g[i][j]
    for i in not_clst:
        for j in clst:
            r += g[i][j]
    return r

def collusion_index(g, clst):
    """Collusion Index of cluster is defined as: 
    (Internal Trading of Cluster) / (External Trading of Cluster)

    Attributes:
        g    -- adjacency matrix of stockflow graph
        clst -- indices of all vertices in cluster

    Outputs:
        r -- collusion index of cluster
    """
    e = external_trading(g, clst)
    if e > 0:
        i = internal_trading(g, clst)
        r = i / e
    else:
        r = float('inf')
    return r

def collusion_level(g, clst1, clst2):
    """Collusion Level of two clusters clst1 and clst2 is defined as:
    Collusion Index of (clst1 union clst2)

    Attributes:
        g    -- adjacency matrix of stockflow graph
        clst1 -- indices of all vertices in cluster 1
        clst2 -- indices of all vertices in cluster 2

    Outputs:
        r -- collusion level of given two clusters
    """
    return collusion_index(g, union(clst1, clst2))

def collusion_sort(g, clstr_set):
    """collusion_sort takes a set of clusters, and returns the set of clusters
    sorted in descending order of their Collusion Indexes

    Attributes:
        g         -- adjacency matrix of stockflow graph
        clstr_set -- list of clusters, eg. [clst1, clst2, clst3]

    Outputs:
        arr -- clstr_set sorted in descending order of Collusion Index of sets
    """
    # values of collusion indexes
    lc = []
    arr = []
    for clst in clstr_set:
        lc.append(collusion_index(g, clst))
    # descending sorted index array of lc values
    sort_indices = np.argsort(-np.asarray(lc))
    # reorder clusters according to sort_indices
    for i in sort_indices:
        arr.append(clstr_set[i])
    return arr

def km_compatiable(g, k, m, p, clst):
    """Point p from cluster1 is km-compatiable with cluster 2 if kNN(p) contains
    atleast min(m, len(cluster2)) vertices.
    Note that the stockflow graph given to this function already has kNN applied
    to it, and all non-kNN nodes filtered. Therefore, we do no repeat this step.

    Attributes:
        g    -- adjacency matrix of stockflow graph
        k    -- number of nearest neighbors to consider
        m    -- value of 1 <= m <= k
        p    -- index of vertex p from cluster1
        clst -- indices of all vertices in cluster 2

    Outputs:
        b -- bool value if p is km-compatiable with given cluster
    """
    """If given graph is not already kNN filtered

    k = knn(g[p])
    c = 0
    for i in knn:
        if(g[p][i] > 0):
            c += 1
        else:
            break
    return c >= min(m, len(clst))
    """
    return np.count_nonzero(g[p]) >= min(m, len(clst))

def kmh_compatiable(g, k, m, h, clst1, clst2):
    """Two clusters clst1, clst2 are said to be kmh-compatiable if atleast h% of
    vertices in clst1 are km-compatiable with clst2, and h% of vertices in clst2
    are km-compatiable with clst1

    Attributes:
        g     -- adjacency matrix of stockflow graph
        k     -- number of nearest neighbors to consider
        m     -- value of 1 <= m <= k
        h     -- value of 0 <= h <= 100, any real value
        clst1 -- indices of all vertices in cluster 2
        clst2 -- indices of all vertices in cluster 2

    Outputs:
        b -- bool value if clst1 and clst2 are kmh-compatiable
    """
    # check clst1 --> clst2 compatiability
    cd_comp = False
    # check clst2 --> clst1 compatiability
    dc_comp = False
    # count of compatiable vertices
    cd_count = 0
    dc_count = 0
    clen = len(clst1)
    dlen = len(clst2)
    for p in clst1:
        # check if each vertex is km-compatiable
        if km_compatiable(g, k, m, p, clst2):
            # increment if it is
            cd_count += 1
            # if we already crossed out breakpoint, then break
            if(cd_count/clen * 100 >= h):
                # mark as compatiable in one direction
                cd_comp = True
                break
    for p in clst2:
        if km_compatiable(g, k, m, p, clst1):
            dc_count += 1
            if(dc_count/dlen * 100 >= h):
                dc_comp = True
                break

    return cd_comp and dc_comp

def label_clusters(ids, clstr_set):
    """Take a cluster set which uses indices to represent the vertexs, replace
    these index vertices with their labels (labels are traderIDs).

    Attributes:
        ids       -- labels of vertices in sequential order
        clstr_set -- list of clusters, eg. [clst1, clst2, clst3]

    Outputs:
        arr -- cluster set with labels instead of indices
    """
    arr = []
    for clst in clstr_set:
        id_clst = []
        for v in clst:
            id_clst.append(ids[v])
        arr.append(id_clst)
    return arr

if __name__ == "__main__":
    # input args
    inputs = sys.argv
    if(len(inputs) == 5):
        DATASET = inputs[1]
        K = int(inputs[2])
        M = int(inputs[3])
        H = float(inputs[4])
    else:
        print("Incorrect Input, resorting to defaults")
        DATASET = "data/placeholder.csv"
        K = 2
        M = 1
        H = 50.0

    ids, g = generate_stockflow_graph(DATASET)
    nodes = len(ids)

    # for every vertex in stockflow graph
    for row in g:
        # find indices of the k-nearest neighbors
        kn_indices = knn(row, K)
        # remove all edges that are not k-nearest neighbors
        for i in range(0, nodes):
            if i not in kn_indices:
                row[i] = 0

    # singleton sets of all vertices in graph g
    s = generate_singletons(nodes)

    while True:
        # sort clusters in s, by the value of the collusion index.
        # paper talks of collusion level, but for only one cluster
        # collusion index = collusion level.
        b =  collusion_sort(g, s)
        # check if changes are being made to s
        change = False
        # for every pair of clusters in b
        for pair in it.combinations(b, 2):
            cclst, dclst = pair
            # if collusion level > 0, and are kmh-compatiable
            if (collusion_level(g, cclst, dclst) > 0 and 
            kmh_compatiable(g, K, M, H, cclst, dclst)):
                # s is being changed
                change = True
                # remove clst1, clst2, add (clst1 union clst2)
                s.remove(cclst)
                s.remove(dclst)
                s.append(union(cclst, dclst))
                break
        if not change:
            # if no further changes to s are being made, then we have our result
            break

    # assign the traderID labels to index vertices
    s =  collusion_sort(g, s)
    S = label_clusters(ids, s)
    print(S)

    """ Use this code only to visualize a graph with less no. of nodes eg. test.csv
    High no. of nodes increases execution time by alot. Uncomment imports.

    G = nx.DiGraph()
    for i, clst in enumerate(s):
        G.add_nodes_from(S[i])
        for pair in it.combinations(clst, 2):
            j, k = pair
            if g[j][k] > 0:
                G.add_edge(ids[j], ids[k], label=g[j][k])
            if g[k][j] > 0:
                G.add_edge(ids[k], ids[j], label=g[k][j])

    pos = nx.drawing.nx_agraph.graphviz_layout(G, prog='dot')
    edge_labels = nx.get_edge_attributes(G, 'label')
    nx.draw(G, pos)
    nx.draw_networkx_edge_labels(G, pos, edge_labels, font_size=8)
    nx.draw_networkx_labels(G, pos, font_size=8)  
    plt.show()
    """
