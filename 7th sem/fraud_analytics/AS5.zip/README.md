# CS6890 - Assignment 5 - Implementation of Collusion Clustering

From Section 4.3 in --
Palshikar, Girish & Apte, Manoj. (2008). Collusion set detection using graph
clustering. Data Min. Knowl. Discov.. 16. 135-164. 10.1007/s10618-007-0076-8. 

Authors:
    - Tanmay R     -- CS17BTECH11042
    - Sai Harsha K -- CS17BTECH11036

Main code is in `main.py`

The folder `data` contains different datasets:
`sample.csv` is the CSV provided with the assignment.
`sample_500.csv` `sample.csv` trimmed to 500 unique nodes
`placeholder.csv` is a simple CSV to check if code passes syntactically.
`test.csv` is a CSV with basic data to test the logic of the code.

Note that `sample.csv` has been modified to have its first row be `seller,buyer,amount`.

Run the algorithm as follows:
`python3 main.py <path_to_dataset> <k> <m> <h>`

`path_to_dataset` must point to a valid csv file, in the right format.
`k` value of k, must be a positive integer
`m` value of m, must be a positive integer <= k
`h` value of h, must be a real value b/w 0 and 100.

Giving the input in incorrect format will lead the program to run with placeholder values.

Example:
`python3 main.py data/test.csv 2 1 90.0`
