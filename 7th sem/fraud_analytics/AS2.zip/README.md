# CS6890 - Assignment 2 - Identifying Fradulent Taxpayers using Variational 
Autoencoders

Authors:
    - Tanmay R     -- CS17BTECH11042
    - Sai Harsha K -- CS17BTECH11036

Main code is in `main.py`

The folder `data` contains different datasets:
`sample.csv` is the CSV provided with the assignment.

Run the VAE as follows:
`python3 main.py`

Various input parameters can be modified in the main function of `main.py`.

DATASET               -- path to dataset
N_EPOCHS              -- no of epochs to train for
INPUT_DIM             -- no of features in input data
HIDDEN_DIM            -- no of features in hidden layer
LATENT_DIM            -- no of features in bottleneck layer
PERCENTILE_THRESHOLDS -- loss values above these percentile will 
                         be considered fraudulent
lr                    -- learning rate
