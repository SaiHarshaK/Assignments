"""
CS6890 - Assignment 2 - Identifying Fradulent Taxpayers using Variational 
Autoencoders

Authors:
    Tanmay R     -- CS17BTECH11042
    Sai Harsha K -- CS17BTECH11036
"""
import os
import torch
import numpy as np
import pandas as pd
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import matplotlib.pyplot as plt
import sklearn.preprocessing as pr

class Encoder(nn.Module):
    """Definition for our encoder. It takes N dimensional input data, learns it
    and extracts H features from it. These H features are again reduced to two
    sets, MU and VAR, which are Z dimensional.

    N Dimension Input Layer --> H Dimension Hidden Layer --> Z Dimension
                                                             Bottleneck Layer

    Attributes:
        input_dim  -- no of features in the input data
        hidden_dim -- no of features in the hidden layer
        z_dim      -- no of features in the bottleneck layer
    """
    def __init__(self, input_dim, hidden_dim, z_dim):
        super().__init__()
        # Input Layer ----> Hidden Layer Pass
        self.linear = nn.Linear(input_dim, hidden_dim)
        # Hidden Layer ----> Bottleneck Layer Passes
        self.mu = nn.Linear(hidden_dim, z_dim)
        self.var = nn.Linear(hidden_dim, z_dim)

    def forward(self, x):
        """Run the encoder on the given data, and output the reduced data.

        Attributes:
            x -- Input Data with `input_dim` features

        Outputs:
            z_mu, z_var -- Z dimensional data in the bottleneck layer
        """
        hidden = F.relu(self.linear(x))
        z_mu = self.mu(hidden)
        z_var = self.var(hidden)
        return z_mu, z_var

class Decoder(nn.Module):
    """Definition for our decoder. It takes Z dimensional input data, and 
    reconstrcuts H features from it. Then, we take these H features and try to
    reconstruct N dimensional data.

    Z Dimension Bottleneck Layer --> H Dimension Hidden Layer --> N Dimension
                                                                  Input Layer
    Attributes:
        z_dim      -- no of features in the bottleneck layer
        hidden_dim -- no of features in the hidden layer
        input_dim  -- no of features in the input data
    """
    def __init__(self, z_dim, hidden_dim, output_dim):
        super().__init__()
        # Bottleneck Layer ----> Hidden Layer Passes
        self.linear = nn.Linear(z_dim, hidden_dim)
        # Hidden Layer ----> Input Layer Pass
        self.out = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        """Run the decoder on the given data, and output the reconstructed data.

        Attributes:
            x -- Input Data with `z_dim` features

        Outputs:
            predicted   -- reconstructed data
        """
        hidden = F.relu(self.linear(x))
        predicted = self.out(hidden)
        return predicted

class VAE(nn.Module):
    """Definition for our Variational Autencoder. It has an Encoder and a 
    Decoder. It takes the Z dimensional output sets Z_MU and Z_VAR from the 
    encoder, and samples data from it. This sampled data is then run through
    a pass of the Decoder, which attempts to reconstruct the original data.

    Input ----> Hidden ----> Bottleneck ----> Hidden ----> Output
    Layer       Layer        Layer            Layer        Layer

    Attributes:
        encoder -- encoder defined on (Input Layer ---> Bottleneck Layer)
        decoder -- decoder defined on (Bottleneck Layer ---> Output Layer)
    """
    def __init__(self, encoder, decoder):
        super().__init__()
        self.encode = encoder
        self.decode = decoder

    def forward(self, x):
        """Run the VAE on the given data, and output the reconstructed data.

        Attributes:
            x -- Input Data with `input_dim` features

        Outputs:
            predicted   -- reconstructed data
            z_mu, z_var -- Z dimensional data in the bottleneck layer
        """
        # Encoder Pass
        z_mu, z_var = self.encode(x)
        # Sample the data we get from the Encoder
        std = torch.exp(z_var / 2)
        eps = torch.randn_like(std)
        x_sample = eps.mul(std).add_(z_mu)
        # Decoder pass on sampled data
        predicted = self.decode(x_sample)
        return predicted, z_mu, z_var

def train(data, model, optimizer):
    """Trains the VAE Model on the given input data

    Attributes:
        data      -- Input Data with `input_dim` features
        model     -- our VAE model
        optimizer -- optimizer for our model

    Outputs:
        total_loss -- sum of all loss values of reconstructed data
    """
    # set model to training mode
    model = model.train()
    # total Loss for current training Epoch
    train_loss = 0
    n_rows = list(data.size())[0]
    for i in range(n_rows):
        x = data[i, :]
        # gradients to zero
        optimizer.zero_grad()
        # run vae on input data
        x_sample, z_mu, z_var = model(x)
        # calculate reconstruction loss and kl loss
        recon_loss = torch.sum((x-x_sample)**2)
        kl_loss = 0.5 * torch.sum(torch.exp(z_var) + z_mu**2 - 1.0 - z_var)
        loss = recon_loss + kl_loss
        # backward pass
        loss.backward()
        train_loss += loss.item()
        # update weights
        optimizer.step()
    return train_loss

def calculate_losses(data, model):
    """Evaulates the given input data with the trained VAE model

    Attributes:
        data      -- Input Data with `input_dim` features
        model     -- our VAE model

    Outputs:
        losses -- loss values for each set of input features
    """
    # set model to eval mode
    model = model.eval()
    losses = []
    n_rows = list(data.size())[0]
    for i in range(n_rows):
        x = data[i, :]
        # run vae on input data
        x_sample, z_mu, z_var = model(x)
        # calculate reconstruction loss and kl loss
        recon_loss = torch.sum((x-x_sample)**2)
        kl_loss = 0.5 * torch.sum(torch.exp(z_var) + z_mu**2 - 1.0 - z_var)
        loss = recon_loss + kl_loss
        # backward pass
        loss.backward()
        losses.append(loss.item())
    return torch.tensor(losses)

def split_tensor(tnsr, th):
    """Splits the given tensor into tensors. One containing all values <= th,
    the second containing all values > th

    Attributes:
        tnsr -- input 1 x N tensor
        th   -- threshold value

    Outputs:
        below_th, above_th -- values <=th, and > th respectively
    """
    below_th = torch.Tensor()
    above_th = torch.Tensor()
    for i in tnsr:
        if i > th:
            above_th = torch.cat((above_th, i.reshape(1, 1)))
        else:
            below_th = torch.cat((below_th, i.reshape(1, 1)))
    return below_th, above_th

def plot_losses(below_th, above_th, th, samples):
    """Plots a double line graph of upto n samples. And a third line dashed line
    showing threshold value.

    Attributes:
        below_th -- values for line graph 1
        above_th -- values for line graph 2
        th       -- threshold value for y = th dashed line
        samples  -- maximum number of samples. (x axis values <= samples)

    Ouputs:
        Plotted Line Graph
    """
    below_samples = below_th[:samples, :]
    above_samples = above_th[:samples, :]
    len_below = list(below_samples.size())[0]
    len_above = list(above_samples.size())[0]
    plt.plot(np.arange(len_below), below_samples, label='Authentic')
    plt.plot(np.arange(len_above), above_samples, label='Fraud')
    plt.plot(np.arange(samples), (np.zeros(samples) + th), "r--", 
            label='Threshold')
    plt.xlabel("N")
    plt.ylabel("Loss")
    plt.legend()
    plt.title("Threshold: {th}".format(th=th))
    plt.show()

if __name__ == "__main__":
    # input args
    DATASET = "data/sample.csv"
    N_EPOCHS = 300
    INPUT_DIM = 9
    OUTPUT_DIM = INPUT_DIM
    HIDDEN_DIM = 7
    LATENT_DIM = 4
    PERCENTILE_THRESHOLDS = [90, 95]
    lr = 1e-3

    data = pd.read_csv(DATASET)
    # normalize our data into 0 mean, 1 variance data
    data = data.values.tolist()
    data = pr.StandardScaler().fit_transform(data)
    # convert data to tensor
    data = torch.tensor(data)
    data = data.float()

    encoder = Encoder(INPUT_DIM, HIDDEN_DIM, LATENT_DIM)
    decoder = Decoder(LATENT_DIM, HIDDEN_DIM, OUTPUT_DIM)

    model = VAE(encoder, decoder)

    optimizer = optim.Adam(model.parameters(), lr=lr)

    # train model for `N_EPOCHS` epochs
    for e in range(N_EPOCHS):
        train_loss = train(data, model, optimizer)
        n_rows = list(data.size())[0]
        # Calculate and print average loss
        train_loss /= n_rows
        print(f'Epoch {e}, Train Loss: {train_loss:.2f}')

    # evaluate data with our vae model and get loss values
    losses = calculate_losses(data, model)

    # calculate the threshold for values above the 
    # `PERCENTILE_THRESHOLD`th percentile
    for PERCENTILE_THRESHOLD in PERCENTILE_THRESHOLDS:
        threshold = np.percentile(losses, PERCENTILE_THRESHOLD)
        # split loss values below and above threshold
        below_th, above_th = split_tensor(losses, threshold)

        # print data and plot graph
        print("Assuming Loss values above", PERCENTILE_THRESHOLD, 
                "percentile are fraudulent.")
        print("Authentic:", list(below_th.size())[0])
        print("Fraudulent:", list(above_th.size())[0])

        plot_losses(below_th, above_th, threshold, 100)
