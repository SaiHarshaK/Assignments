void printVertical(char text[]);

void readString(char *text,int);

