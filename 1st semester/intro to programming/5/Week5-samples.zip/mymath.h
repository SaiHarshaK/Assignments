#define PI 3.1416

long powermod(long,unsigned long, long);

double circleArea(double);

double squareRoot(double);
