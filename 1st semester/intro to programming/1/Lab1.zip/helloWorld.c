/********************************
*Filename: helloWorld.c
*********************************/

#include<stdio.h>

main()
{
    printf("\n Hello, World.");
}
