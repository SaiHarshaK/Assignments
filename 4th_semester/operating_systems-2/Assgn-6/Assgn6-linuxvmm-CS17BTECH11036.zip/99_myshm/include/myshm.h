#ifndef __MYSHM__
#define MYSHM_LEN (1024 * 1024) // 1MB
#endif

